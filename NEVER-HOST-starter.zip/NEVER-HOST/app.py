import io
import json
import os
import re
import signal
import subprocess
import sys
import time
import uuid
import zipfile
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
BOTS = DATA / "bots"
STATE_FILE = DATA / "state.json"
MAX_UPLOAD = 2 * 1024 * 1024
MAX_LOG = 12000
DATA.mkdir(exist_ok=True)
BOTS.mkdir(exist_ok=True)

app = FastAPI(title="NEVER-HOST♥️")
app.mount("/files", StaticFiles(directory=str(BOTS)), name="files")

def load_state():
    if not STATE_FILE.exists():
        return {}
    try:
        return json.loads(STATE_FILE.read_text("utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}

def save_state(state):
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), "utf-8")

def safe_name(name: str) -> str:
    name = Path(name or "bot.py").name
    name = re.sub(r"[^a-zA-Z0-9_.-]", "_", name)
    return name[:100] or "bot.py"

def read_log(path: Path) -> str:
    try:
        return path.read_text("utf-8", errors="replace")[-MAX_LOG:]
    except OSError:
        return ""

def alive(proc_info) -> bool:
    pid = proc_info.get("pid")
    if not pid:
        return False
    try:
        os.kill(int(pid), 0)
        return True
    except (OSError, ValueError, TypeError):
        return False

PAGE = r"""<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>NEVER-HOST♥️</title><style>
:root{color-scheme:dark;--bg:#0b0b12;--card:#151521;--line:#2c2b3c;--pink:#ff5e9c;--muted:#a9a7bc}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at top,#25132c,#0b0b12 55%);color:#f7f5ff;font:15px system-ui,sans-serif}
main{max-width:900px;margin:auto;padding:28px 16px 60px}.brand{display:flex;align-items:center;gap:14px;margin-bottom:26px}.logo{width:52px;height:52px;border-radius:17px;background:#2c1930;color:#ff6ca7;display:grid;place-items:center;font-size:27px}
h1{font-size:25px;margin:0}p{color:var(--muted);margin:5px 0}.tag{font-size:12px;border:1px solid #5a3650;color:#ff9cc2;padding:5px 9px;border-radius:20px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.card{background:#151521dd;border:1px solid var(--line);border-radius:18px;padding:20px;box-shadow:0 12px 40px #0003}h2{font-size:17px;margin:0 0 16px}
label{display:block;color:#cbc8db;font-size:13px;margin:13px 0 7px}input,textarea{width:100%;border:1px solid #39374b;border-radius:10px;background:#0e0e17;color:#fff;padding:12px;font:inherit}input[type=file]{padding:9px}button,.btn{border:0;border-radius:10px;background:var(--pink);color:#240d19;font-weight:750;padding:11px 15px;cursor:pointer;text-decoration:none;display:inline-block;margin-top:14px}button.secondary{background:#29283a;color:#f5f1ff;border:1px solid #414056}.hint{font-size:12px;color:var(--muted);line-height:1.5}.bot{padding:14px 0;border-top:1px solid var(--line)}.bot:first-child{border-top:0}.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.status{color:#8cf0b4;font-size:12px}.status.off{color:#b4b1c4}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#090910;border:1px solid var(--line);border-radius:10px;padding:12px;color:#d9d4e8;font-size:12px;max-height:220px;overflow:auto}.notice{background:#352719;border:1px solid #79552d;color:#ffd9a3;border-radius:12px;padding:12px;margin-bottom:18px;font-size:13px;line-height:1.5}
@media(max-width:680px){.grid{grid-template-columns:1fr}main{padding:20px 12px}}
</style></head><body><main>
<header class="brand"><div class="logo">♥</div><div><h1>NEVER-HOST<span style="color:#ff6ca7">♥️</span></h1><p>Твоя панель управления ботами</p></div><span class="tag">BETA</span></header>
<div class="notice"><b>Локальный прототип.</b> Не публикуйте эту панель в интернете: здесь пока нет входа в аккаунт и изоляции запускаемого кода. Не загружайте чужие или неизвестные файлы.</div>
<div class="grid"><section class="card"><h2>＋ Добавить бота</h2><form action="/upload" method="post" enctype="multipart/form-data">
<label>Название бота</label><input name="name" placeholder="Например, My Telegram Bot" required maxlength="60">
<label>Токен Telegram</label><input name="token" type="password" placeholder="123456:ABC..." required autocomplete="new-password">
<label>Файл бота (.py или .zip)</label><input type="file" name="file" accept=".py,.zip" required>
<p class="hint">Для ZIP: файл main.py должен находиться в корне архива. Лимит загрузки — 2 МБ. Зависимости из ZIP автоматически не устанавливаются.</p>
<button type="submit">Загрузить бота</button></form></section>
<section class="card"><h2>Мои боты</h2><div id="bots">Загрузка списка…</div></section></div>
<section class="card" style="margin-top:16px"><h2>Логи выбранного бота</h2><p class="hint">Обнови страницу после запуска, чтобы увидеть свежие логи.</p><div id="logs"><p>Выбери бота в списке.</p></div></section>
<p class="hint" style="text-align:center;margin-top:24px">NEVER-HOST♥️ · Prototype v0.1</p>
</main><script>
async function refresh(){let r=await fetch('/api/bots');let data=await r.json();let el=document.getElementById('bots');if(!data.length){el.innerHTML='<p>Пока нет ботов. Загрузи первый файл слева.</p>';return}
el.innerHTML=data.map(b=>`<div class="bot"><b>${esc(b.name)}</b><div class="hint">${esc(b.filename)} · <span class="status ${b.running?'':'off'}">${b.running?'Работает':'Остановлен'}</span></div><div class="row"><button onclick="act('${b.id}','start')">▶ Запустить</button><button class="secondary" onclick="act('${b.id}','stop')">■ Остановить</button><button class="secondary" onclick="logs('${b.id}')">Логи</button></div></div>`).join('')}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function act(id,action){let r=await fetch('/api/bots/'+id+'/'+action,{method:'POST'});let d=await r.json();alert(d.message||d.detail||'Готово');refresh()}
async function logs(id){let r=await fetch('/api/bots/'+id+'/logs');let d=await r.json();document.getElementById('logs').innerHTML='<pre>'+esc(d.logs||'Логов пока нет')+'</pre>'}
refresh();
</script></body></html>"""

@app.get("/", response_class=HTMLResponse)
def home():
    return PAGE

@app.get("/health")
def health():
    return {"ok": True, "service": "NEVER-HOST"}

@app.post("/upload")
async def upload(name: str = Form(...), token: str = Form(...), file: UploadFile = File(...)):
    if len(token.strip()) < 20 or ":" not in token:
        raise HTTPException(400, "Проверь формат токена Telegram.")
    raw = await file.read(MAX_UPLOAD + 1)
    if not raw or len(raw) > MAX_UPLOAD:
        raise HTTPException(413, "Файл пустой или превышает 2 МБ.")
    filename = safe_name(file.filename or "bot.py")
    bot_id = uuid.uuid4().hex[:10]
    bot_dir = BOTS / bot_id
    bot_dir.mkdir(parents=True)
    if filename.lower().endswith(".py"):
        (bot_dir / "main.py").write_bytes(raw)
    elif filename.lower().endswith(".zip"):
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as z:
                candidates = [i for i in z.infolist() if Path(i.filename).name == "main.py" and "/" not in i.filename.strip("/")]
                if not candidates:
                    raise HTTPException(400, "В ZIP должен быть main.py в корне архива.")
                info = candidates[0]
                if info.file_size > MAX_UPLOAD:
                    raise HTTPException(413, "main.py внутри ZIP слишком большой.")
                (bot_dir / "main.py").write_bytes(z.read(info))
        except zipfile.BadZipFile:
            raise HTTPException(400, "Некорректный ZIP-архив.")
    else:
        raise HTTPException(400, "Разрешены только .py и .zip.")
    state = load_state()
    state[bot_id] = {"id": bot_id, "name": name[:60], "filename": filename, "token": token.strip(),
                     "dir": str(bot_dir), "created": int(time.time()), "pid": None, "log": str(bot_dir / "bot.log")}
    save_state(state)
    return RedirectResponse("/", status_code=303)

@app.get("/api/bots")
def list_bots():
    state = load_state()
    return [{"id": b["id"], "name": b["name"], "filename": b["filename"], "running": alive(b)}
            for b in state.values()]

@app.post("/api/bots/{bot_id}/start")
def start_bot(bot_id: str):
    state = load_state()
    b = state.get(bot_id)
    if not b:
        raise HTTPException(404, "Бот не найден.")
    if alive(b):
        return {"message": "Бот уже запущен."}
    log_path = Path(b["log"])
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_file = open(log_path, "a", encoding="utf-8")
    env = os.environ.copy()
    env["TELEGRAM_BOT_TOKEN"] = b["token"]
    try:
        proc = subprocess.Popen([sys.executable, "-u", "main.py"], cwd=b["dir"], env=env,
                                stdout=log_file, stderr=subprocess.STDOUT,
                                start_new_session=(os.name != "nt"))
    except OSError as e:
        log_file.close()
        raise HTTPException(500, f"Не удалось запустить: {e}")
    b["pid"] = proc.pid
    b["started"] = int(time.time())
    save_state(state)
    log_file.close()
    return {"message": "Процесс запускается. Проверь логи через несколько секунд."}

@app.post("/api/bots/{bot_id}/stop")
def stop_bot(bot_id: str):
    state = load_state()
    b = state.get(bot_id)
    if not b:
        raise HTTPException(404, "Бот не найден.")
    if not alive(b):
        b["pid"] = None
        save_state(state)
        return {"message": "Бот уже остановлен."}
    try:
        os.kill(int(b["pid"]), signal.SIGTERM)
    except OSError:
        pass
    b["pid"] = None
    save_state(state)
    return {"message": "Команда остановки отправлена."}

@app.get("/api/bots/{bot_id}/logs")
def bot_logs(bot_id: str):
    b = load_state().get(bot_id)
    if not b:
        raise HTTPException(404, "Бот не найден.")
    return {"logs": read_log(Path(b["log"]))}
